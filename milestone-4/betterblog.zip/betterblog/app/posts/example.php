<?php $PAGE='Example';$SUBTITLE='A Test Post';$LASTEDIT='2023-02-24T01:21:34+0000';$AUTHOR='admin';include("../include/postheader.php");?>

This is an example post.

<?php 
echo strtoupper("We can do PHP here!");
?>