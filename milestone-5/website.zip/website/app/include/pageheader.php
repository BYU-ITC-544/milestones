<div class="media">
    <!-- <div class="media-left">
        <figure class="image is-48x48">
            <img src="https://bulma.io/images/placeholders/96x96.png" alt="Placeholder image">
        </figure>
    </div> -->
    <div class="media-content">
        <p class="title is-1 has-text-centered"><?php echo $PAGE; ?></p>
    </div>
</div>

<div class="content">
    <hr>