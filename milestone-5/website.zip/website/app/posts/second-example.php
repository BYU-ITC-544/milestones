<?php $PAGE='Example';$SUBTITLE='An example';$LASTEDIT='2023-04-12T02:05:25+0000';$AUTHOR='test';include("../include/postheader.php");?>

This is an example post.

<?php 
echo strtoupper("We can do PHP here as well!");
?>

<p>
    Lots of content can go here!
</p>