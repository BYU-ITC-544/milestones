<?php $PAGE='Example2'; include("../include/pageheader.php");?>
<p>
    This is an example page!
</p>


<?php 
echo strtoupper("We can do PHP here!");
?>