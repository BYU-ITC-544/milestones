<?php $PAGE='Example';$SUBTITLE='This is Cool!';$LASTEDIT='2023-04-12T02:06:17+0000';$AUTHOR='test';include("../include/postheader.php");?>

This is an example post.

<?php 
echo strtoupper("We can do PHP here!");
?>