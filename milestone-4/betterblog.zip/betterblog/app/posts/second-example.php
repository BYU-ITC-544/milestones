<?php $PAGE='Example';$SUBTITLE='Another Test Post';$LASTEDIT='2023-02-24T01:21:03+0000';$AUTHOR='admin';include("../include/postheader.php");?>

This is an example post.

<?php 
echo strtoupper("We can do PHP here as well!");
?>

<p>
    Lots of content can go here!
</p>